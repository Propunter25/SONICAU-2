<!DOCTYPE html>
<html lang="en">
<head>
    <title>400 Bad Request</title>
    <link rel="icon" type="image/x-icon" href="/favicon.ico">
</head>
    <body style="background-color: white; text-align: center;">
        <h1>400 Bad Request</h1>
        <hr>
        nginx
    </body>
</html>
